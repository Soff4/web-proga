ALTER TABLE `#__fields_values` MODIFY `value` MEDIUMTEXT;
