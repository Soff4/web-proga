/**
 * @package   akeebabackup
 * @copyright Copyright (c)2006-2024 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

DROP TABLE IF EXISTS `#__akeebabackup_profiles`;
DROP TABLE IF EXISTS `#__akeebabackup_backups`;
DROP TABLE IF EXISTS `#__akeebabackup_storage`;