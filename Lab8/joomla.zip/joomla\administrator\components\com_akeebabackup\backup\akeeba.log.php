DEBUG   |20240510 10:26:13|Fetching filter data from database
DEBUG   |20240510 10:26:13|Loading filters
DEBUG   |20240510 10:26:13|-- Loading filter Directories
DEBUG   |20240510 10:26:13|-- Loading filter Extradirs
DEBUG   |20240510 10:26:13|-- Loading filter Files
DEBUG   |20240510 10:26:13|-- Loading filter Incremental
DEBUG   |20240510 10:26:13|-- Loading filter Multidb
DEBUG   |20240510 10:26:13|-- Loading filter Regexdirectories
DEBUG   |20240510 10:26:13|-- Loading filter Regexfiles
DEBUG   |20240510 10:26:13|-- Loading filter Regexskipdirs
DEBUG   |20240510 10:26:13|-- Loading filter Regexskipfiles
DEBUG   |20240510 10:26:13|-- Loading filter Regextabledata
DEBUG   |20240510 10:26:13|-- Loading filter Regextables
DEBUG   |20240510 10:26:13|-- Loading filter Skipdirs
DEBUG   |20240510 10:26:13|-- Loading filter Skipfiles
DEBUG   |20240510 10:26:13|-- Loading filter Tabledata
DEBUG   |20240510 10:26:13|-- Loading filter Tables
DEBUG   |20240510 10:26:13|-- Loading filter Tablesalwaysskipped
DEBUG   |20240510 10:26:13|-- Loading filter Cvsfolders
DEBUG   |20240510 10:26:13|-- Loading filter Excludefiles
DEBUG   |20240510 10:26:13|-- Loading filter Excludefolders
DEBUG   |20240510 10:26:13|-- Loading filter Excludetabledata
DEBUG   |20240510 10:26:13|-- Loading filter Joomlaskipdirs
DEBUG   |20240510 10:26:13|-- Loading filter Joomlaskipfiles
DEBUG   |20240510 10:26:13|-- Loading filter Libraries
DEBUG   |20240510 10:26:13|-- Loading filter Publicfolder
DEBUG   |20240510 10:26:13|-- Loading filter Sitedb
DEBUG   |20240510 10:26:13|-- Loading filter Siteroot
DEBUG   |20240510 10:26:13|-- Loading filter Systemcachefiles
DEBUG   |20240510 10:26:13|Loading optional filters
DEBUG   |20240510 10:26:13|-- Loading optional filter Stack\StackErrorlogs
DEBUG   |20240510 10:26:13|-- Loading optional filter Stack\StackHoststats
DEBUG   |20240510 10:26:13|-- Loading optional filter Stack\StackActionlogs
DEBUG   |20240510 10:26:13|-- Loading optional filter Stack\StackFinder
